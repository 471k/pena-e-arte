# Database Instructions — MySQL 8.4 + EF Core 10

> Load this file when working on entities, migrations, DbContext,
> or anything in `TattooStudio.Infrastructure/Persistence/`.

---

## DbContext Setup

```csharp
// Infrastructure/Persistence/AppDbContext.cs
public class AppDbContext(
    DbContextOptions<AppDbContext> options,
    ICurrentTenant tenant) : DbContext(options)
{
    public DbSet<Appointment> Appointments => Set<Appointment>();
    public DbSet<Client>      Clients      => Set<Client>();
    public DbSet<Artist>      Artists      => Set<Artist>();
    public DbSet<Studio>      Studios      => Set<Studio>();
    public DbSet<Design>      Designs      => Set<Design>();
    public DbSet<Payment>     Payments     => Set<Payment>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        // Load all IEntityTypeConfiguration via assembly scan
        builder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);

        // Global query filters — tenant isolation on every query
        builder.Entity<Appointment>().HasQueryFilter(a => a.StudioId == tenant.StudioId);
        builder.Entity<Client>().HasQueryFilter(c => c.StudioId == tenant.StudioId);
        builder.Entity<Design>().HasQueryFilter(d => d.StudioId == tenant.StudioId);
        builder.Entity<Payment>().HasQueryFilter(p => p.StudioId == tenant.StudioId);
        // Studios table is NOT filtered — owned by issuer, queried cross-tenant
    }
}
```

---

## Entity Configuration Pattern

Never put EF attributes on domain entities. Use `IEntityTypeConfiguration`.

```csharp
// Infrastructure/Persistence/Configurations/AppointmentConfiguration.cs
public class AppointmentConfiguration : IEntityTypeConfiguration<Appointment>
{
    public void Configure(EntityTypeBuilder<Appointment> builder)
    {
        builder.ToTable("appointments");

        builder.HasKey(a => a.Id);
        builder.Property(a => a.Id).ValueGeneratedOnAdd();

        builder.Property(a => a.StudioId).IsRequired();
        builder.Property(a => a.Status)
               .HasConversion<string>()
               .HasMaxLength(32);

        builder.HasIndex(a => new { a.StudioId, a.ArtistId, a.Date })
               .HasDatabaseName("ix_appointments_studio_artist_date");

        builder.HasOne(a => a.Artist)
               .WithMany(ar => ar.Appointments)
               .HasForeignKey(a => a.ArtistId)
               .OnDelete(DeleteBehavior.Restrict);
    }
}
```

---

## Naming Conventions (MySQL)

| Object | Convention | Example |
|---|---|---|
| Tables | snake_case, plural | `appointments` |
| Columns | snake_case | `studio_id`, `created_at` |
| Indexes | `ix_table_columns` | `ix_appointments_studio_artist_date` |
| FK constraints | `fk_table_reference` | `fk_appointments_artists` |
| Primary keys | `pk_table` | `pk_appointments` |

---

## Tenant Isolation Rules

**Query with filter (default — all tenant-scoped entities):**
```csharp
// Tenant filter applied automatically
var appointments = await _db.Appointments.ToListAsync(ct);
```

**Query without filter (`issuer` role cross-tenant queries only):**
```csharp
// Only use IgnoreQueryFilters in IssuerOnly-authorized handlers
var allAppointments = await _db.Appointments
    .IgnoreQueryFilters()
    .Where(a => a.Date >= from)
    .ToListAsync(ct);
```

Never call `IgnoreQueryFilters()` in a handler that is not behind `IssuerOnly` policy.

---

## Base Entity

All tenant-scoped entities inherit from this:

```csharp
// Domain/Entities/TenantEntity.cs
public abstract class TenantEntity
{
    public Guid      Id        { get; init; } = Guid.NewGuid();
    public Guid      StudioId  { get; set; }  // tenant key
    public DateTime  CreatedAt { get; init; } = DateTime.UtcNow;
    public DateTime  UpdatedAt { get; set; }  = DateTime.UtcNow;
}
```

---

## Migrations

Always name migrations descriptively.

```bash
# Add migration
dotnet ef migrations add AddAppointmentDepositColumn \
  --project src/TattooStudio.Infrastructure \
  --startup-project src/TattooStudio.API

# Apply
dotnet ef database update \
  --project src/TattooStudio.Infrastructure \
  --startup-project src/TattooStudio.API
```

**Zero-downtime migration order for breaking changes:**
1. Add new nullable column → migrate
2. Deploy code writing to both columns
3. Backfill data
4. Deploy code reading from new column
5. Make column non-nullable → migrate
6. Remove old column in a later release

---

## Soft Deletes

Tenant data is soft-deleted, never hard-deleted (GDPR right to erasure is
handled by a separate purge pipeline, not by direct DELETE).

```csharp
// Add to TenantEntity
public DateTime? DeletedAt { get; set; }

// Add to query filters
builder.Entity<Client>().HasQueryFilter(c =>
    c.StudioId == tenant.StudioId && c.DeletedAt == null);
```

---

## Useful Queries

```csharp
// Check slot availability (accounts for buffer time)
var conflict = await _db.Appointments
    .Where(a =>
        a.ArtistId == artistId &&
        a.Date < requestEnd &&
        a.EndDate > requestStart &&
        a.Status != AppointmentStatus.Cancelled)
    .AnyAsync(ct);

// Paginated list — always cursor-based, never offset
var results = await _db.Appointments
    .Where(a => a.Id > lastSeenId)
    .OrderBy(a => a.Date)
    .Take(pageSize)
    .ToListAsync(ct);
```

---

## Redis Patterns

```csharp
// Appointment slot lock (prevent double-booking race condition)
var lockKey = $"slot:{studioId}:{artistId}:{date:yyyyMMddHHmm}";
var acquired = await _cache.SetAsync(lockKey, "1",
    new DistributedCacheEntryOptions { AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(30) },
    when: When.NotExists);

if (!acquired) throw new SlotAlreadyBookedException();

// Session store key convention
// session:{userId}
// ratelimit:{tenantId}:{endpoint}
// slot:{studioId}:{artistId}:{datetime}
```
